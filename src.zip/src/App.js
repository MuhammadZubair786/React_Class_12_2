
import Navigation from './Config/Navigation';

function App() {
  return (
   <Navigation/>
  );
}

export default App;
